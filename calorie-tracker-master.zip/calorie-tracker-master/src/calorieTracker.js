const calculateWeightLostInAMonth = (cycling,running,swimming,extraCalorieInTake) =>{
   let weightLostInAMonth = 0;
   
  if (cycling<=0 || running<=0 || swimming<=0 || extraCalorieInTake<=0) {
   weightLostInAMonth=-1;
  }
  else {
   weightLostInAMonth=((4*(cycling*2))+(4*(swimming*2))+(4*(running*2)))-(30*extraCalorieInTake)/1000;
  }
   return weightLostInAMonth;
   
}

module.exports = calculateWeightLostInAMonth

